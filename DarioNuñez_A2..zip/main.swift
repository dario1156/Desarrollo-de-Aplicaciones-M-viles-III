// Estructura para representar un artículo
struct Article {
    var name: String
    var quantity: Int
}

// Función para leer una entrada de la consola
func readLineString() -> String? {
    if let input = readLine(), !input.isEmpty {
        return input
    }
    return nil
}

// Función para leer un número entero de la consola
func readLineInt() -> Int? {
    if let input = readLine(), let number = Int(input) {
        return number
    }
    return nil
}

// Función para registrar un nuevo artículo
func registerArticle(inventory: inout [Article]) {
    print("Ingrese el nombre del artículo:")
    if let name = readLineString() {
        print("Ingrese la cantidad:")
        if let quantity = readLineInt() {
            let newArticle = Article(name: name, quantity: quantity)
            inventory.append(newArticle)
            print("El artículo \(name) ha sido registrado con éxito.")
        } else {
            print("Cantidad inválida. Inténtelo nuevamente.")
        }
    } else {
        print("Nombre de artículo inválido. Inténtelo nuevamente.")
    }
}

// Función para mostrar la lista de artículos en el inventario
func viewArticles(inventory: [Article]) {
    if inventory.isEmpty {
        print("El inventario está vacío.")
    } else {
        print("Lista de artículos en el inventario:")
        for (index, article) in inventory.enumerated() {
            print("\(index + 1). \(article.name) - Cantidad: \(article.quantity)")
        }
    }
}

// Función para consultar la cantidad de un artículo en el inventario
func checkStock(inventory: [Article]) {
    print("Ingrese el nombre del artículo a consultar:")
    if let name = readLineString() {
        if let article = inventory.first(where: { $0.name == name }) {
            print("El artículo \(name) tiene \(article.quantity) unidades en existencia.")
        } else {
            print("El artículo \(name) no está registrado en el inventario.")
        }
    } else {
        print("Nombre de artículo inválido. Inténtelo nuevamente.")
    }
}

// Función principal que ejecuta el programa
func runInventoryApp() {
    var inventory: [Article] = []
    var shouldExit = false

    while !shouldExit {
        print("----- Menú -----")
        print("1. Registrar un artículo")
        print("2. Ver la lista de artículos")
        print("3. Consultar los artículos en existencia")
        print("4. Salir")
        print("Ingrese el número de opción:")

        if let option = readLineInt() {
            switch option {
            case 1:
                registerArticle(inventory: &inventory)
            case 2:
                viewArticles(inventory: inventory)
            case 3:
                checkStock(inventory: inventory)
            case 4:
                shouldExit = true
                print("Saliendo del programa...")
            default:
                print("Opción inválida. Inténtelo nuevamente.")
            }
        } else {
            print("Opción inválida. Inténtelo nuevamente.")
        }
    }
}

// Ejecutar la función principal para iniciar el programa
runInventoryApp()
