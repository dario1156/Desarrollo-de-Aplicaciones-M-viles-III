import Foundation

// Función para leer una entrada de la consola
func readLineInt() -> Int? {
    if let input = readLine(), let number = Int(input) {
        return number
    }
    return nil
}

print("Introduce el número:")

if let num = readLineInt() {
    // Con if
    if num % 2 == 0 {
        print("El número \(num) es par")
    } else {
        print("El número \(num) es impar")
    }
    
    // Con el operador ternario
    print("El número \(num) es " + (num % 2 == 0 ? "par" : "impar"))
} else {
    print("Ingresa un número válido.")
}
