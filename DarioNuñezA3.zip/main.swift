// Función para leer una entrada de la consola
func readLineDouble() -> Double? {
    if let input = readLine(), let number = Double(input) {
        return number
    }
    return nil
}

// Función para calcular el área del cuadrado
func areaCuadrado() {
    print("Ingrese el lado del cuadrado:")
    if let lado = readLineDouble() {
        let area = lado * lado
        print("El área del cuadrado es: \(area)")
    } else {
        print("Valor inválido. Inténtelo nuevamente.")
    }
}

// Función para calcular el área del rectángulo
func areaRectangulo() {
    print("Ingrese la base del rectángulo:")
    if let base = readLineDouble() {
        print("Ingrese la altura del rectángulo:")
        if let altura = readLineDouble() {
            let area = base * altura
            print("El área del rectángulo es: \(area)")
        } else {
            print("Valor inválido. Inténtelo nuevamente.")
        }
    } else {
        print("Valor inválido. Inténtelo nuevamente.")
    }
}

// Función para calcular el área del triángulo
func areaTriangulo() {
    print("Ingrese la base del triángulo:")
    if let base = readLineDouble() {
        print("Ingrese la altura del triángulo:")
        if let altura = readLineDouble() {
            let area = 0.5 * base * altura
            print("El área del triángulo es: \(area)")
        } else {
            print("Valor inválido. Inténtelo nuevamente.")
        }
    } else {
        print("Valor inválido. Inténtelo nuevamente.")
    }
}

// Función para calcular el área del círculo
func areaCirculo() {
    print("Ingrese el radio del círculo:")
    if let radio = readLineDouble() {
        let area = Double.pi * radio * radio
        print("El área del círculo es: \(area)")
    } else {
        print("Valor inválido. Inténtelo nuevamente.")
    }
}

// Función principal que ejecuta el programa
func runAreaCalculator() {
    var shouldExit = false

    while !shouldExit {
        print("----- Menú -----")
        print("1. Área del cuadrado")
        print("2. Área del rectángulo")
        print("3. Área del triángulo")
        print("4. Área del círculo")
        print("5. Salir")
        print("Ingrese el número de opción:")

        if let input = readLine(), let option = Int(input) {
            switch option {
            case 1:
                areaCuadrado()
            case 2:
                areaRectangulo()
            case 3:
                areaTriangulo()
            case 4:
                areaCirculo()
            case 5:
                shouldExit = true
                print("Saliendo del programa...")
            default:
                print("Opción inválida. Inténtelo nuevamente.")
            }
        } else {
            print("Opción inválida. Inténtelo nuevamente.")
        }
    }
}

// Ejecutar la función principal para iniciar el programa
runAreaCalculator()
